public class Main {
    public static void main(String[] args) {
        System.out.println("1 2 3 4 5 ");
        System.out.println("6 7 8 9 10 ");
        System.out.println("11 12 13 14 15 ");
        System.out.println("16 17 18 19 20 ");
        System.out.printf("Мой номер-87767188943=Сумма %d ", (8+7+7+6+7+1+8+8+9+4+3));
    }
}
